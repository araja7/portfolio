import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;

/**
 * Controller class.
 *
 * @author Put your name here
 */
public final class NNCalcController1 implements NNCalcController {

    /**
     * Model object.
     */
    private final NNCalcModel model;

    /**
     * View object.
     */
    private final NNCalcView view;

    /**
     * Useful constants.
     */
    private static final NaturalNumber TWO = new NaturalNumber2(2),
            INT_LIMIT = new NaturalNumber2(Integer.MAX_VALUE);

    /**
     * Updates this.view to display this.model, and to allow only operations
     * that are legal given this.model.
     *
     * @param model
     *            the model
     * @param view
     *            the view
     * @ensures [view has been updated to be consistent with model]
     */
    private static void updateViewToMatchModel(NNCalcModel model,
            NNCalcView view) {

        // TODO: fill in body
        //get top and bottom
        NaturalNumber top = new NaturalNumber2(model.top());
        NaturalNumber bottom = new NaturalNumber2(model.bottom());
        //update view
        view.updateTopDisplay(top);
        view.updateBottomDisplay(bottom);
        //update permissions
        view.updateDivideAllowed(!bottom.isZero());
        view.updatePowerAllowed(bottom.compareTo(INT_LIMIT) <= 0);
        view.updateSubtractAllowed(top.compareTo(bottom) >= 0);
        view.updateRootAllowed(
                bottom.compareTo(TWO) >= 0 && bottom.compareTo(INT_LIMIT) <= 0);
    }

    /**
     * Constructor.
     *
     * @param model
     *            model to connect to
     * @param view
     *            view to connect to
     */
    public NNCalcController1(NNCalcModel model, NNCalcView view) {
        this.model = model;
        this.view = view;
        updateViewToMatchModel(model, view);
    }

    @Override
    public void processClearEvent() {
        /*
         * Get alias to bottom from model
         */
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        bottom.clear();
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processSwapEvent() {
        /*
         * Get aliases to top and bottom from model
         */
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        NaturalNumber temp = top.newInstance();
        temp.transferFrom(top);
        top.transferFrom(bottom);
        bottom.transferFrom(temp);
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processEnterEvent() {

        // TODO: fill in body
        //get top and bottom
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();
        top.copyFrom(bottom);
        //update view
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processAddEvent() {

        // TODO: fill in body
        //get top and bottom
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();
        //creates a natural number 0 to copy from
        NaturalNumber zero = new NaturalNumber2(0);
        bottom.add(top);
        top.copyFrom(zero);
        //update view
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processSubtractEvent() {
        // TODO: fill in body
        //makes sure the requires clause of the contract is fulfilled
        assert this.model.top()
                .compareTo(this.model
                        .bottom()) >= 0 : "Must subract a number less than or "
                                + "equal to the original number";
        //get top and bottom
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();
        //creates a natural number 0 to copy from
        NaturalNumber zero = new NaturalNumber2(0);
        top.subtract(bottom);
        bottom.copyFrom(top);
        top.copyFrom(zero);
        //update view
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processMultiplyEvent() {

        // TODO: fill in body
        //get top and bottom
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();
        //creates a natural number 0 to copy from
        NaturalNumber zero = new NaturalNumber2(0);
        bottom.multiply(top);
        top.copyFrom(zero);
        //update view
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processDivideEvent() {
        // TODO: fill in body
        //ensures the requires clause of the contract is fulfilled
        assert !this.model.bottom().isZero() : "Can't divide by 0";
        //get top and bottom
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();
        //creates a temp for the remainder
        NaturalNumber temp = top.divide(bottom);
        bottom.copyFrom(top);
        top.copyFrom(temp);
        //update view
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processPowerEvent() {

        // TODO: fill in body
        //ensures requires clause of the contract is met
        assert this.model.bottom().compareTo(
                INT_LIMIT) <= 0 : "The power must be lower than the int limit";
        //gets top and bottom
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();
        //creates a natural number 0 to copy from
        NaturalNumber zero = new NaturalNumber2(0);
        top.power(bottom.toInt());
        bottom.copyFrom(top);
        top.copyFrom(zero);
        //updates view
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processRootEvent() {

        // TODO: fill in body
        //ensures requires clause of the contract is met
        assert this.model.bottom().compareTo(TWO) >= 0 && this.model.bottom()
                .compareTo(INT_LIMIT) <= 0 : "The root must be in between 2 "
                        + "and the int limit";
        //gets top and bottom
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();
        //creates a natural number 0 to copy from
        NaturalNumber zero = new NaturalNumber2(0);
        top.root(bottom.toInt());
        bottom.copyFrom(top);
        top.copyFrom(zero);
        //updates view
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processAddNewDigitEvent(int digit) {

        // TODO: fill in body
        //ensures requires clause of the contract is met
        assert digit >= 0
                && digit < 10 : "Digit must be in between 0 (inclusive) "
                        + "and 10 (exclusive)";
        //gets bottom and makes a natural number for the digit
        NaturalNumber bottom = this.model.bottom();
        NaturalNumber d = new NaturalNumber2(digit);
        bottom.multiplyBy10(0);
        bottom.add(d);
        updateViewToMatchModel(this.model, this.view);
    }

}
