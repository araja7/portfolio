import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.FormatChecker;

/**
 * Put a short phrase describing the program here.
 *
 * @author Put your name here
 *
 */
public final class ABCDGuesser2 {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private ABCDGuesser2() {
    }

    /**
     * Repeatedly asks the user for a positive real number until the user enters
     * one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number entered by the user
     */
    private static double getPositiveDouble(SimpleReader in, SimpleWriter out) {
        String s = in.nextLine();
        double a = 0;
        //checks to see if input is a number, if not keeps asking until it is a number
        while (!FormatChecker.canParseDouble(s)) {
            s = in.nextLine();
        }
        if (FormatChecker.canParseDouble(s)) {
            a = Double.parseDouble(s);
            //keeps running until input is a positive number
            while (a <= 0 && FormatChecker.canParseDouble(s)) {
                s = in.nextLine();
                if (FormatChecker.canParseDouble(s)) {
                    a = Double.parseDouble(s);
                } else {
                    while (!FormatChecker.canParseDouble(s)) {
                        s = in.nextLine();
                        if (FormatChecker.canParseDouble(s)) {
                            a = Double.parseDouble(s);
                        }
                    }
                }
            }
        }
        return a;
    }

    /**
     * Repeatedly asks the user for a positive real number not equal to 1.0
     * until the user enters one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number not equal to 1.0 entered by the user
     */
    private static double getPositiveDoubleNotOne(SimpleReader in,
            SimpleWriter out) {
        String s = in.nextLine();
        double a = 0;
        //checks to see if input is a number, if not keeps asking until it is a number
        while (!FormatChecker.canParseDouble(s)) {
            s = in.nextLine();
        }
        if (FormatChecker.canParseDouble(s)) {
            a = Double.parseDouble(s);
            //keeps running until input is a positive number
            while (a <= 1 && FormatChecker.canParseDouble(s)) {
                s = in.nextLine();
                if (FormatChecker.canParseDouble(s)) {
                    a = Double.parseDouble(s);
                } else {
                    while (!FormatChecker.canParseDouble(s)) {
                        s = in.nextLine();
                        if (FormatChecker.canParseDouble(s)) {
                            a = Double.parseDouble(s);
                        }
                    }
                }
            }
        }
        return a;

    }

    private static void results(double approx, double a, double b, double c,
            double d, double pError, SimpleWriter out) {
        out.println("Value of the formula: " + approx);
        out.println("Percent error: " + pError);
        out.println("Exponent a: " + a);
        out.println("Exponent b: " + b);
        out.println("Exponent c: " + c);
        out.println("Exponent d: " + d);
    }

    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        double u = getPositiveDouble(in, out);
        double w = getPositiveDoubleNotOne(in, out);
        double x = getPositiveDoubleNotOne(in, out);
        double y = getPositiveDoubleNotOne(in, out);
        double z = getPositiveDoubleNotOne(in, out);
        double[] possibleValues = { -5, -4, -3, -2, -1, -1.0 / 2, -1.0 / 3,
                -1.0 / 4, 0, 1.0 / 4, 1.0 / 3, 1.0 / 2, 1, 2, 3, 4, 5 };

        double approx = 0;
        double min = Math.abs(u - approx);
        double a = 0;
        double b = 0;
        double c = 0;
        double d = 0;
        double approx1 = 0;
        double pError = 0;
        //goes through all the possible combinations of the exponents
        for (int i = 0; i < possibleValues.length; i++) {
            for (int j = 0; j < possibleValues.length; j++) {
                for (int k = 0; k < possibleValues.length; k++) {
                    for (int l = 0; l < possibleValues.length; l++) {
                        approx = Math.pow(w, possibleValues[i])
                                * Math.pow(x, possibleValues[j])
                                * Math.pow(y, possibleValues[k])
                                * Math.pow(z, possibleValues[l]);
                        /*
                         * if the approximation is closer than the previous
                         * approximation, update the values of the
                         * approximation, the exponents and the percent error
                         */
                        if (Math.abs(u - approx) < min) {
                            a = possibleValues[i];
                            b = possibleValues[j];
                            c = possibleValues[k];
                            d = possibleValues[l];
                            min = Math.abs(approx - u);
                            pError = (min / u) * 100;
                            approx1 = approx;
                        }
                    }
                }
            }
        }
        results(approx1, a, b, c, d, pError, out);

        in.close();
        out.close();
    }

}
