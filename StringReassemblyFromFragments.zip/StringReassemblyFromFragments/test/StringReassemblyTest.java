import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

public class StringReassemblyTest {

    @Test
    public void combination() {
        String s1 = "hello";
        String s2 = "loop";
        int overlap = 2;
        String expected = "helloop";
        String s = StringReassembly.combination(s1, s2, overlap);
        assertEquals(expected, s);
    }

    @Test
    public void combination1() {
        String s1 = "wheel";
        String s2 = "eel";
        int overlap = 3;
        String expected = "wheel";
        String s = StringReassembly.combination(s1, s2, overlap);
        assertEquals(expected, s);
    }

    @Test
    public void addToSetAvoidingSubstrings() {
        Set<String> strSet = new Set1L();
        strSet.add("hello");
        strSet.add("world");
        strSet.add("dog");
        strSet.add("tyrannosaurus");
        String str = "hellooo";
        Set<String> expected = new Set1L();
        expected.add("world");
        expected.add("dog");
        expected.add("tyrannosaurus");
        expected.add("hellooo");
        StringReassembly.addToSetAvoidingSubstrings(strSet, str);
        assertEquals(expected, strSet);
    }

    @Test
    public void addToSetAvoidingSubstrings1() {
        Set<String> strSet = new Set1L();
        strSet.add("hello");
        strSet.add("world");
        strSet.add("dog");
        strSet.add("tyrannosaurus");
        String str = "robot";
        Set<String> expected = new Set1L();
        expected.add("world");
        expected.add("dog");
        expected.add("tyrannosaurus");
        expected.add("hello");
        expected.add("robot");
        StringReassembly.addToSetAvoidingSubstrings(strSet, str);
        assertEquals(expected, strSet);
    }

    @Test
    public void addToSetAvoidingSubstrings2() {
        Set<String> strSet = new Set1L();
        strSet.add("hello");
        strSet.add("world");
        strSet.add("dog");
        strSet.add("tyrannosaurus");
        String str = "hell";
        Set<String> expected = new Set1L();
        expected.add("world");
        expected.add("dog");
        expected.add("tyrannosaurus");
        expected.add("hello");
        StringReassembly.addToSetAvoidingSubstrings(strSet, str);
        assertEquals(expected, strSet);
    }

    @Test
    public void linesFromInput() {
        String str1 = "this";
        String str2 = "is";
        String str3 = "is not";
        String str4 = "cool";
        SimpleWriter out = new SimpleWriter1L("test.txt");
        out.println(str1);
        out.println(str2);
        out.println(str3);
        out.println(str4);
        Set<String> expected = new Set1L();
        expected.add(str1);
        expected.add(str3);
        expected.add(str4);
        SimpleReader input = new SimpleReader1L("test.txt");
        Set<String> strSet = StringReassembly.linesFromInput(input);
        assertEquals(expected, strSet);
    }

    @Test
    public void linesFromInput1() {
        String str1 = "this";
        String str2 = "is";
        String str4 = "cool";
        SimpleWriter out = new SimpleWriter1L("test.txt");
        out.println(str1);
        out.println(str2);
        out.println(str4);
        Set<String> expected = new Set1L();
        expected.add(str1);
        expected.add(str4);
        SimpleReader input = new SimpleReader1L("test.txt");
        Set<String> strSet = StringReassembly.linesFromInput(input);
        assertEquals(expected, strSet);
    }

    @Test
    public void linesFromInput2() {
        String str1 = "hi";
        String str2 = "bye";
        String str3 = "pie";
        String str4 = "cry";
        SimpleWriter out = new SimpleWriter1L("test.txt");
        out.println(str1);
        out.println(str2);
        out.println(str3);
        out.println(str4);
        Set<String> expected = new Set1L();
        expected.add(str1);
        expected.add(str2);
        expected.add(str3);
        expected.add(str4);
        SimpleReader input = new SimpleReader1L("test.txt");
        Set<String> strSet = StringReassembly.linesFromInput(input);
        assertEquals(expected, strSet);
    }

    @Test
    public void printWithLineSeparators() {
        String text = "hi~bye pie~lie";
        SimpleWriter out = new SimpleWriter1L("test2.txt");
        StringReassembly.printWithLineSeparators(text, out);
        SimpleReader input = new SimpleReader1L("test2.txt");
        Set<String> output = StringReassembly.linesFromInput(input);
        Set<String> expected = new Set1L();
        expected.add("hi");
        expected.add("bye pie");
        expected.add("lie");
        assertEquals(expected, output);
    }

    @Test
    public void printWithLineSeparators1() {
        String text = "striker~eureka~rocket";
        SimpleWriter out = new SimpleWriter1L("test2.txt");
        StringReassembly.printWithLineSeparators(text, out);
        SimpleReader input = new SimpleReader1L("test2.txt");
        Set<String> output = StringReassembly.linesFromInput(input);
        Set<String> expected = new Set1L();
        expected.add("striker");
        expected.add("eureka");
        expected.add("rocket");
        assertEquals(expected, output);
    }
}
