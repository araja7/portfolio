import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.xmltree.XMLTree;
import components.xmltree.XMLTree1;

/**
 * Program to evaluate XMLTree expressions of {@code int}.
 *
 * @author Arnav Rajashekara
 *
 */
public final class XMLTreeIntExpressionEvaluator {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private XMLTreeIntExpressionEvaluator() {
    }

    /**
     * Evaluate the given expression.
     *
     * @param exp
     *            the {@code XMLTree} representing the expression
     * @return the value of the expression
     * @requires <pre>
     * [exp is a subtree of a well-formed XML arithmetic expression]  and
     *  [the label of the root of exp is not "expression"]
     * </pre>
     * @ensures evaluate = [the value of the expression]
     */
    private static int evaluate(XMLTree exp) {
        assert exp != null : "Violation of: exp is not null";
        //creates answer variable to hold the answer
        int answer = 0;
        //checks if the root is a tag
        if (exp.isTag()) {
            //checks if the tag is addition
            if (exp.label().equals("plus")) {
                //creates new xml trees for each of the children to evaluate
                XMLTree xml = exp.child(0);
                XMLTree xml1 = exp.child(1);
                /*
                 * calls evaluate on each of the xml trees and performs the
                 * operation on them and updates answer
                 */
                answer = evaluate(xml) + evaluate(xml1);
                //checks if the tag is division
            } else if (exp.label().equals("divide")) {
                XMLTree xml = exp.child(0);
                XMLTree xml1 = exp.child(1);
                answer = evaluate(xml) / evaluate(xml1);
                //checks if the tag is multiplication
            } else if (exp.label().equals("times")) {
                XMLTree xml = exp.child(0);
                XMLTree xml1 = exp.child(1);
                answer = evaluate(xml) * evaluate(xml1);
                //checks if the tag is subtraction
            } else if (exp.label().equals("minus")) {
                XMLTree xml = exp.child(0);
                XMLTree xml1 = exp.child(1);
                answer = evaluate(xml) - evaluate(xml1);
                //checks if the tag is a number
            } else if (exp.label().equals("number")) {
                //gets the number
                answer = Integer.parseInt(exp.attributeValue("value"));

            }
        }
        return answer;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Enter the name of an expression XML file: ");
        String file = in.nextLine();
        while (!file.equals("")) {
            XMLTree exp = new XMLTree1(file);
            out.println(evaluate(exp.child(0)));
            out.print("Enter the name of an expression XML file: ");
            file = in.nextLine();
        }

        in.close();
        out.close();
    }

}
