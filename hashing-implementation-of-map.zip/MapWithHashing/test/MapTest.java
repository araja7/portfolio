import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.map.Map;
import components.map.Map.Pair;

/**
 * JUnit test fixture for {@code Map<String, String>}'s constructor and kernel
 * methods.
 *
 * @author Put your name here
 *
 */
public abstract class MapTest {

    /**
     * Invokes the appropriate {@code Map} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new map
     * @ensures constructorTest = {}
     */
    protected abstract Map<String, String> constructorTest();

    /**
     * Invokes the appropriate {@code Map} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new map
     * @ensures constructorRef = {}
     */
    protected abstract Map<String, String> constructorRef();

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the implementation
     * under test type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsTest = [pairs in args]
     */
    private Map<String, String> createFromArgsTest(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorTest();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the reference
     * implementation type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsRef = [pairs in args]
     */
    private Map<String, String> createFromArgsRef(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorRef();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    /**
     * Test constructor with no parameter.
     */
    @Test
    public void constructorTest1() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> map = this.constructorTest();
        Map<String, String> expected = this.constructorRef();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(map, expected);
    }

    /**
     * Test add.
     */
    @Test
    public void addTest1() {
        Map<String, String> map1 = this.createFromArgsTest("one", "1", "two",
                "2");
        Map<String, String> expected = this.createFromArgsRef("one", "1", "two",
                "2", "three", "3");

        map1.add("three", "3");
        assertEquals(map1, expected);
    }

    /**
     * Test add starting with empty.
     */
    @Test
    public void addTest2() {
        Map<String, String> map1 = this.constructorTest();
        Map<String, String> expected = this.createFromArgsRef("one", "1");

        map1.add("one", "1");
        assertEquals(map1, expected);
    }

    /**
     * Test remove
     */
    @Test
    public void removeTest1() {
        Map<String, String> map1 = this.createFromArgsTest("one", "1", "two",
                "2");
        Map<String, String> expected = this.createFromArgsRef("one", "1");

        map1.remove("two");
        assertEquals(map1, expected);
    }

    /**
     * Test remove when going to empty.
     */
    @Test
    public void removeTest2() {
        Map<String, String> map1 = this.createFromArgsTest("one", "1");
        Map<String, String> expected = this.constructorTest();

        map1.remove("one");
        assertEquals(map1, expected);
    }

    /**
     * Test removeAny.
     */
    @Test
    public void removeAnyTest1() {
        Map<String, String> map1 = this.createFromArgsTest("one", "1", "two",
                "2", "three", "3");
        Pair<String, String> removed = map1.removeAny();
        Map<String, String> expected = this.createFromArgsTest("one", "1",
                "two", "2", "three", "3");
        expected.remove(removed.key());

        assertEquals(map1, expected);
    }

    /**
     * Test removeAny when going to empty
     */
    public void removeAnyTest2() {
        Map<String, String> map1 = this.createFromArgsTest("one", "1");
        map1.removeAny();
        Map<String, String> expected = this.constructorTest();

        assertEquals(map1, expected);

    }

    /**
     * Test value.
     */
    @Test
    public void valueTest1() {
        Map<String, String> map1 = this.createFromArgsTest("one", "1", "two",
                "2", "three", "3");
        String ans = map1.value("one");
        String expected = "1";

        assertEquals(ans, expected);
    }

    /**
     * Test value again.
     */
    @Test
    public void valueTest2() {
        Map<String, String> map1 = this.createFromArgsTest("one", "1", "two",
                "2", "three", "3");
        String ans = map1.value("three");
        String expected = "3";

        assertEquals(ans, expected);
    }

    /**
     * Test hasKey.
     */
    @Test
    public void hasKeyTest() {
        Map<String, String> map1 = this.createFromArgsTest("one", "1", "two",
                "2", "three", "3");
        boolean expected = true;
        assertEquals(map1.hasKey("three"), expected);
    }

    /**
     * Test hasKey when it is false.
     */
    @Test
    public void hasKeyTest2() {
        Map<String, String> map1 = this.createFromArgsTest("one", "1", "two",
                "2", "three", "3");
        boolean expected = false;
        assertEquals(map1.hasKey("four"), expected);
    }

    /**
     * Test size.
     */
    @Test
    public void sizeTest() {
        Map<String, String> map1 = this.createFromArgsTest("one", "1", "two",
                "2", "three", "3");
        final int size = 3;
        assertEquals(map1.size(), size);
    }

    /**
     * Test size when empty.
     */
    @Test
    public void sizeTest2() {
        Map<String, String> map1 = this.constructorTest();
        int size = 0;
        assertEquals(map1.size(), size);

    }

}