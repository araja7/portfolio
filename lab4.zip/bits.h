/* Arnav Rajashekara */

unsigned int get_VX(unsigned short code);
unsigned int get_coin_x(unsigned short code);
unsigned int get_coin_y(unsigned short code);
unsigned int get_color(unsigned short code);
unsigned int get_jump_V(unsigned short code);
bool isCoin(unsigned int code);
bool isMascot(unsigned int code);
bool validCoin(unsigned int code);
bool valid_brutus(unsigned short code);
