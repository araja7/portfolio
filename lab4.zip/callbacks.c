//Arnav Rajashekara
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "structs.h"
#include "linkedlist.h"
#include "physics.h"
#include "debug.h"
#include "callbacks.h"

//comparison function for y position
bool compare_y(void *data1, void *data2) {
    struct Buckeye *brutus1 = data1;
    struct Buckeye *brutus2 = data2;
    if ((brutus1->y_position) < (brutus2->y_position))
    {
        return true;
    }else{
        return false;
    }
}

//comparison function for loot
bool compare_score(void *data1, void *data2) {
    struct Buckeye *brutus1 = data1;
    struct Buckeye *brutus2 = data2;
    if ((get_score(brutus1)) < (get_score(brutus2)))
    {
        return true;
    }else{
        return false;
    }
}

//comparison function for coin color
bool compare_color(void *data1, void *data2) {
    struct Coin *coin1 = data1;
    struct Coin *coin2 = data2;
    if ((coin1->color) > (coin2->color))
    {
        return true;
    }else{
        return false;
    }
}

//criteria function to clear lists
bool clear_list(void *data, void *helper) {
    return true;
}


