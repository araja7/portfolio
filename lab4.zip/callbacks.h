/* Arnav Rajashekara */

bool clear_list(void *data, void *helper);
bool compare_color(void *data1, void *data2);
bool compare_score(void *data1, void *data2);
bool compare_y(void *data1, void *data2);
