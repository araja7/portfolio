for file in bits.c input.c lab2.c output.c physics.c
do
	vi $file < hereis1
done
