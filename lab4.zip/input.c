/* Copyright 2023, Neil Kirby.  Not for disclosure without permission */
//Edited by Arnav Rajashekara
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "callbacks.h"
#include "structs.h"
#include "output.h"
#include "bits.h"
#include "physics.h"
#include "lab4.h"
#include "sim.h"
#include "linkedlist.h"
#include "debug.h"
#include "memory.h"
#include "input.h"

//function to check valid input - made by arnav rajashekara
bool valid_input(unsigned short code){
	if(isMascot(code)){
		return valid_brutus(code);
	}else if(isCoin(code)){
		return validCoin(code);
	}else{
		return false;
	}
}

//function to deal with mascot - made by arnav rajashekara
void deal_with_mascot(unsigned short code, void *data){
	struct Sim *world = data;
	struct Buckeye *brutus = allocateMemory(sizeof(struct Buckeye));
	if (brutus != NULL){
		initialize_brutus(brutus, code, world);
		if(!insert(&world->mascots, brutus, compare_y, TEXT)){
			freeMemory(brutus);
			brutus = NULL;
		}
	}
}

//function to deal with coin - made by arnav rajashekara
void deal_with_coin(unsigned short code, void *data){
	struct Sim *world = data;
	struct Coin *c = allocateMemory(sizeof(struct Coin));
	if (c != NULL){
		initialize_coin(c, code);
		if(!insert(&world->coins, c, compare_color, TEXT)){
			freeMemory(c);
			c = NULL;
		}
	}
}

//function to deal with input - made by arnav rajashekara
void deal_with_input(unsigned short code, void *data){
	struct Sim *world = data;
	if(isMascot(code)){
		deal_with_mascot(code, world);
	}else{
		deal_with_coin(code, world);
	}
}

//function to check if the game is on - made by arnav rajashekara
bool game_on(void *data, void *helper){
	struct Sim *world = data;
	if(any(world->mascots, is_left_of_flag, NULL) > 0){
		return true;
	}else{
		return false;
	}
}

//function that returns whether the simulation was successful or not, also runs the simulation - made by arnav rajashekara
bool good_input_run(struct Sim *world, FILE *file) {
    int tokens;
    unsigned short code;
    while(1 == (tokens = fscanf(file, "%hx", &code))) {
        if (valid_input(code)) {
            deal_with_input(code, world);
        } else {
            output_bad_bits(code);
            return false;
        }
    }
    output_scanf(tokens);
    return tokens == EOF;
}



