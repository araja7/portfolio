/* Arnav Rajashekara */

void deal_with_coin(unsigned short code, void *data);
void deal_with_input(unsigned short code, void *data);
void deal_with_mascot(unsigned short code, void *data);
bool game_on(void *data, void *helper);
bool good_input_run(struct Sim *world, FILE *file);
bool valid_input(unsigned short code);
