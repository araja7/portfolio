// COpyright 2024 Neil Kirby
//Edited by Arnav Rajashekara
// Not for distribution without permission
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>
#include "structs.h"
#include "constants.h"
#include "debug.h"
#include "linkedlist.h"
#include "btp.h"
#include "n2.h"
#include "bits.h"
#include "input.h"
#include "output.h"
#include "callbacks.h"
#include "memory.h"
#include "sim.h"
#include "physics.h"
#include "lab4.h"



//constants to determine if init or input are bad
#define RVAL_BAD_INIT (1)
#define RVAL_BAD_INPUT (2)


/* I own all inits.  In future labs, I might morph to master init and call
 * my init minions to do the various subtasks.  For now, I'm simple enough
 * to do it all easily myself.  I shield main for all details about
 * initializations */ //edited by arnav rajashekara
bool init(int argc, char *argv[]){
    if (argc < 2) {
        fprintf(stderr, "ERROR: insufficient args - no filename given\n");
        return false;
    }
    if(argc == 3){
        fprintf(stderr, "ERROR: Bonus code is not present\n");
        return false;
    }
    const char *file_name = argv[1];
    if (access(file_name, F_OK) == -1) {
        fprintf(stderr, "ERROR: Unable to open %s for reading.\n", argv[1]);
        return false;
    }
    printf("DIAGNOSTIC: Successfully opened xf.btp for reading.\n");
	/* we might take manual control over what we feed btp_init
	 * SO that we turn it off but still debug our code. */
	return(TEXT || ( GRAPHICS && btp_initialize(false)));

}

/* Put all of the toys away.  In future labs I will own more stuff and
 * call my minions to do those things. */
void teardown()
{
	if(GRAPHICS)btp_teardown();
}

//main to run everything - made by arnav rajashekara
int main(int argc, char *argv[]) {
    int rval = EXIT_SUCCESS;
    double start, runtime;
    struct Sim data = {0.0, NULL, NULL};
    struct Sim *world = &data;
    start = now(); 
    FILE *file = fopen(argv[1], "r");
    if (init(argc, argv)) {
        if (good_input_run(world, file)) {
            fclose(file);
            printf("DIAGNOSTIC: Input file closed.\n");
            sim_loop(world);
        } else {
            rval = RVAL_BAD_INIT;  
        }
        teardown();
    }
    printf("Returning %d\n", rval);
    runtime = now() - start;
    printf("Total runtime is %.9lf seconds\n", runtime);
    return rval;
}


