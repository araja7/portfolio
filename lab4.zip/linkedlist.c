//Arnav Rajashekara
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "btp.h"
#include "n2.h"
#include "debug.h"
#include "callbacks.h"
#include "altmem.h"
#include "linkedlist.h"

//node struct typedef - made by neil kirby
typedef struct Node{
 struct Node *next;
 void *data;
 }Node;

//function to allocate node
static Node *allocate_node(void *data) {
    static int allocation_count = 0;
    Node *node = alternative_malloc(sizeof(Node));
    if (node != NULL) {
        node->data = data;
        node->next = NULL;
        allocation_count++;
        if(TEXT){printf("DIAGNOSTIC: %d nodes allocated.\n", allocation_count);}
        if(DEBUG){printf("DEBUG: linkedlist: allocated pointer is %p\n", node->data);}
    } else {
        if(TEXT){printf("ERROR: linkedlist: Failed to malloc a Node\n");}
    }
    return node;
}

//function to free node
static void free_node(Node *node) {
    static int free_count = 0;
    if (node != NULL) {
        if(DEBUG){printf("DEBUG: linkedlist: about to free %p\n", node->data);}
        alternative_free(node);
        free_count++;
        if(TEXT){printf("DIAGNOSTIC: %d nodes freed.\n", free_count);}
    }
}

//insert function for linked list
bool insert(void *p2head, void *data, ComparisonFunction goesInFrontOf, int text) {
    Node **head = p2head;
    Node *newNode = allocate_node(data);
    if (!newNode) {
        return false;
    }
    if (*head == NULL || goesInFrontOf(data, (*head)->data)) {
        newNode->next = *head;
        *head = newNode;
        return true;
    }
    Node *current = *head;
    while (current->next != NULL && !goesInFrontOf(data, current->next->data)) {
        current = current->next;
    }
    newNode->next = current->next;
    current->next = newNode;
    return true;
}

//iterate function for linked list
void iterate(void *head, ActionFunction doThis) {
    Node *current = head;
    while (current != NULL) {
        doThis(current->data);
        current = current->next;
    }
}

//any function for linked list
bool any(void *head, CriteriaFunction yes, void *helper) {
    Node *current = head;
    while (current != NULL) {
        if (yes(current->data, helper)) {
            return true;
        }
        current = current->next;
    }
    return false;
}

//sort function for linked list
void sort(void *hptr, ComparisonFunction cf){  
    bool swapped;
    Node *current;  
    Node *temp = NULL;  
    if (hptr == NULL){ 
        return; 
    } 
    do{  
        swapped = false;  
        current = hptr;  
        while (current->next != temp){  
            if (cf(current->data,current->next->data)){  
                void *t = current->data;  
                current->data = current->next->data;  
                current->next->data = t;
                swapped = true;  
            }  
            current = current->next;  
        }  
        temp = current;  
    }  
    while (swapped);  
}  

//delete some for linked list
int deleteSome(void *p2head, CriteriaFunction mustGo, void *helper, ActionFunction disposal, int text) {
    Node **head = p2head;
    int deleted = 0;
    Node *current = *head;
    Node *prev = NULL;
    while (current != NULL) {
        if (mustGo(current->data, helper)) {
            if (prev == NULL) {
                *head = current->next;
            } else {
                prev->next = current->next;
            }
            if (disposal) {
                disposal(current->data);
            }
            free_node(current);
            deleted++;
            if (prev != NULL) {
                current = prev->next;
            } else {
                current = *head;
            }
        } else {
            prev = current;
            current = current->next;
        }
    }
    return deleted;
}


