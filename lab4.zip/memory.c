//Arnav Rajashekara
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include "debug.h"
#include "altmem.h"
#include "memory.h"

//function to allocate memory
void *allocateMemory(size_t size) {
    static int objects = 0;
    void *ptr = alternative_malloc(size);
    if (ptr != NULL) {
        objects++;
        if(DEBUG){printf("DEBUG: memory: allocated pointer is %p\n", ptr);}
        if(TEXT){printf("DIAGNOSTIC: allocation #%d allocated %zu bytes\n", objects, size);}
    }else{
        if(TEXT){printf("ERROR: memory: failed to allocate %zu bytes\n", size);}
    }
    return ptr;
}

//function to free memory
void freeMemory(void* ptr) {
    static int count = 0;
    if (ptr != NULL) {
        count++;
        if(DEBUG){printf("DEBUG: memory: about to free %p\n", ptr);}
        if(TEXT){
            printf("DIAGNOSTIC: %d objects freed\n", count);
        }
        alternative_free(ptr);
    }
}