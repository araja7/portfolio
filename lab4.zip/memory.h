/* Arnav Rajashekara */

void *allocateMemory(size_t size);
void freeMemory(void* ptr);
