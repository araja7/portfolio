// Copyright 2024 Neil Kirby
//Edited by Arnav Rajashekara
// Not for distribution without permission

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "structs.h"
#include "debug.h"
#include "btp.h"
#include "constants.h"
#include "n2.h"
#include "physics.h"
#include "sim.h"
#include "callbacks.h"
#include "linkedlist.h"
#include "output.h"


//function to return color as a string - made by arnav rajashekara
static const char *team(char color){
	 static const char* colors[] = {"Black", "Red", "Green", "Yellow", "Blue", "Magenta", "Cyan", "White"};
	 return(colors[color]);
}

//function to draw coin - made by neil kirby
static void draw_coin(void * data)
{
	struct Coin *cash = data;
	btp_coin(cash->color, cash->x_position, cash->y_position);
}

//function to draw brutus - made by neil kirby
static void draw_brutus(void * data)
{
	struct Buckeye *brutus = data;
	btp_brutus(get_score(brutus), brutus->color, brutus->x_position, brutus->y_position, true);
}

//function to draw everything - made by neil kirby
static void master_draw(struct Sim *world){
	btp_clear();
	btp_time( (int) (1000 * world->elapsed));

	iterate(world->mascots, draw_brutus);
	iterate(world->coins, draw_coin);

	btp_refresh();
	microsleep( (unsigned int) (DELTA_TIME * 1000000));
}

//function to print the coin - made by neil kirby, edited by arnav rajashekara
static void print_coin (void * data){
	struct Coin *cash = data;

	printf("%7s    (%8.5lf, %8.5lf)\n",
	    team(cash->color), cash->x_position, cash->y_position);

}

//function to print brutus - made by neil kirby, edited by arnav rajashekara
static void print_brutus (void * data){
	struct Buckeye *brutus = data;

	printf("%3d    %7s    (%8.5lf, %8.5lf)    (%9.5lf, %9.5lf)\n",
	    get_score(brutus), team(brutus->color), 
	    brutus->x_position,
	    brutus->y_position,
	    brutus->x_velocity,
	    brutus->y_velocity);

}

//function to print everything - made by neil kirby, edited by arnav rajashekara
static void master_print(struct Sim *world){
	// do the header, then brutus
	
	printf("\nPts       Team    (__X_____, __Y_____)    (__VX_____, __VY_____) ET=%8.5lf\n", world->elapsed);
    iterate(world->mascots, print_brutus);
	printf( "\n   Team    (__X_____, __Y_____)\n" );
	iterate(world->coins, print_coin);
}

//function to draw everything under the conditions necessary - made by neil kirby
static void final_draw (struct Sim *world)
{
	double delay = 0.0;
	while (delay < 4.0)
	{
	    master_draw(world);
	    delay += DELTA_TIME;
	}
}

//function to output everything - made by neil kirby
void final_output(struct Sim *world)
{
	if(GRAPHICS)
	{
	    final_draw(world);
	}
	if(TEXT)
	{
	    master_print(world);
	}
}

//function to output everything - made by neil kirby
void master_output(struct Sim *world)
{
	if(GRAPHICS)master_draw(world);
	if(TEXT)master_print(world);
}

// messages
//flag message function - made by neil kirby, edited by arnav rajashekara
void flag_message(void *data){
	struct Buckeye *brutus = data;
	if(GRAPHICS)
	{
	    btp_status("Brutus makes it to the flag");
	}
	if(TEXT)
	{
	    printf("\n%s Brutus makes it to the flag!\n", team(brutus->color));
	}
}

//loot message function - made by neil kirby, edited by arnav rajashekara
void loot_message(void *data){
	struct Buckeye *brutus = data;
	if(TEXT)printf("%s Brutus finds loot at %8.5lf, %8.5lf\n", team(brutus->color), brutus->x_position, brutus->y_position);
	if(GRAPHICS)btp_status("Brutus finds some loot");
}

//ceiling message function - made by neil kirby, edited by arnav rajashekara
void ceiling_message(struct Buckeye *brutus)
{
	if(TEXT)printf("%s Brutus hits the ceiling at %8.5lf, %8.5lf\n", team(brutus->color), brutus->x_position, brutus->y_position);
	if(GRAPHICS)btp_status("Brutus hits the ceiling");

}

//floor message function - made by neil kirby, edited by arnav rajashekara
void floor_message(struct Buckeye *brutus)
{
	if(TEXT)printf("%s Brutus hits the floor at %8.5lf, %8.5lf\n", team(brutus->color), brutus->x_position, brutus->y_position);
	if(GRAPHICS)btp_status("Brutus hits the floor");

}

//jump message function - made by neil kirby, edited by arnav rajashekara
void jump_message(struct Buckeye *brutus)
{
	if(TEXT)printf("%s Brutus jumps at %8.5lf, %8.5lf\n", team(brutus->color), brutus->x_position, brutus->y_position);
	if(GRAPHICS)btp_status("Brutus jumps");

}

//function to output an error with bad bits - made by neil kirby
void output_bad_bits(unsigned short code)
{
	if(TEXT)printf("ERROR: invalid input: hex %X\n", code);
}

//scan f function - made by neil kirby
void output_scanf(int tokens)
{
	if(TEXT)printf("scanf returned %d\n", tokens);
}


