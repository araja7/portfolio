/* Arnav Rajashekara */

void ceiling_message(struct Buckeye *brutus);
void final_output(struct Sim *world);
void flag_message(void *data);
void floor_message(struct Buckeye *brutus);
void jump_message(struct Buckeye *brutus);
void loot_message(void *data);
void master_output(struct Sim *world);
void output_bad_bits(unsigned short code);
void output_scanf(int tokens);
