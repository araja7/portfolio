// COpyright 2024 Neil Kirby
//Edited by Arnav Rajashekara
// Not for distribution without permission

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "structs.h"
#include "btp.h"
#include "constants.h"
#include "bits.h"
#include "output.h"
#include "linkedlist.h"
#include "callbacks.h"
#include "physics.h"

// stuff only we should know about
#define FLAG_LIMIT (13.25)
#define G ( -10.0 )

//function to initialize brutus - made by arnav rajashekara
void initialize_brutus(void *data1, unsigned short code, void *data2){
	struct Buckeye *brutus = data1;
	struct Sim *world = data2;
	brutus->x_velocity = get_VX(code);
	brutus->jump_velocity = get_jump_V(code);
	brutus->y_velocity = 0.0;
	brutus->color = get_color(code);
	brutus->y_position = 0.5;
	brutus->x_position = 0.5;
	brutus->loot = 0;
	brutus->sim_ptr = world;
}

//function to intialize coin - made by arnav rajashekara
void initialize_coin(void *data1, unsigned short code){
	struct Coin *c = data1;
	c->color = get_color(code);
	c->x_position = get_coin_x(code) + 0.5;
	c->y_position = get_coin_y(code) + 0.5;
}

//criteria function to check if a mascot is left of flag - edited by arnav rajashekara
bool is_left_of_flag(void *data, void *helper){
	struct Buckeye *brutus = data;
	return(brutus->x_position < FLAG_LIMIT);
}

//function for basic motion - made by neil kirby
static void basic_motion(struct Buckeye *brutus){
	brutus->x_position += DELTA_TIME * brutus->x_velocity;
	brutus->y_position += brutus->y_velocity * DELTA_TIME + 
		0.5* G * DELTA_TIME * DELTA_TIME;
	brutus->y_velocity += G * DELTA_TIME;
}

//function for x and y adjustments - made by neil kirby
static void make_adjustments(struct Buckeye *brutus){
	double XA = btp_X_adjustment(brutus->x_position, brutus->y_position);
	brutus->x_position += XA;

	double YA = btp_Y_adjustment(brutus->x_position, brutus->y_position);
	brutus->y_position += YA;

	if(YA != 0.0) brutus->y_velocity = 0.0;

	if(brutus->x_position >= FLAG_LIMIT){
		flag_message(brutus);
	}
}

//function to get the score - made by Neil Kirby, edited by arnav rajashekara
int get_score(void *data){
	struct Buckeye *brutus = data;
	if(is_left_of_flag(brutus, NULL)){
	    return (int) (brutus->loot + brutus->x_position);
	}
	else{
	    return (int)  (brutus->loot + brutus->x_position + brutus->y_position);
	}
}

//function to move brutus position - made by arnav rajashekara
void move_brutus_position(void *data){
	struct Buckeye *brutus = data;
	basic_motion(brutus);
	make_adjustments(brutus);
}

//action function to move brutus - made by neil kirby, edited by arnav rajashekara
void move_brutus(void *data){
	struct Buckeye *brutus = data;
	if (brutus->x_position < FLAG_LIMIT){
		double oldX = brutus->x_position, oldY = brutus->y_position, oldVY = brutus->y_velocity;
		move_brutus_position(brutus);
		if((oldVY != 0.0) && (brutus->y_velocity == 0.0)){
		// if I was moving in Y and now I am not, I hit
		// the floor (or maybe a ceiling)
			if(oldVY < 0.0)floor_message(brutus);
			if(oldVY > 0.0)ceiling_message(brutus);
		}

	// I didn't move, I have to jump.
		if(oldX == brutus->x_position && oldY == brutus->y_position) {
	    	brutus->y_velocity = brutus->jump_velocity;
	    	jump_message(brutus);
		}
	}
}
	

