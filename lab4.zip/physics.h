/* Arnav Rajashekara */

int get_score(void *data);
void initialize_brutus(void *data1, unsigned short code, void *data2);
void initialize_coin(void *data1, unsigned short code);
bool is_left_of_flag(void *data, void *helper);
void move_brutus(void *data);
void move_brutus_position(void *data);
