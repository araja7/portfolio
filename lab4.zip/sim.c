//Arnav Rajashekara
// list < > style headers first
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#include "structs.h"
#include "constants.h"
#include "debug.h"
#include "btp.h"
#include "n2.h"
#include "bits.h"
#include "input.h"
#include "output.h"
#include "memory.h"
#include "physics.h"
#include "callbacks.h"
#include "linkedlist.h"
#include "sim.h"


/*//function for the simulation loop - made by Neil Kirby
void sim_loop(int color, struct Buckeye *brutus)
{
	double elapsed = 0.0;

	while(game_on(brutus))
	{
	    master_output(brutus->sim_ptr);

	    elapsed += DELTA_TIME;
	    move_brutus(brutus);

	}
	final_output(brutus->sim_ptr);

}

//function to initialize everything and run the simulation - made by Neil Kirby
void load_and_go(unsigned short code)
{  
	struct Buckeye *brutus;
	void *ptr;
	ptr = malloc(sizeof(struct Buckeye));
	brutus = ptr;
	initialize_brutus(brutus, code, world);
	sim_loop(get_color(code), brutus);
}*/

//function to move everyone - made by arnav rajashekara
void move_everyone(void *data){
	struct Sim *world = data;
	iterate(world->mascots, move_brutus);
}

//function to sweep coins - made by arnav rajashekara
void sweep_coins(void *data){
	struct Buckeye *brutus = data;
	int count = deleteSome(&brutus->sim_ptr->coins, my_coin, brutus, freeMemory, TEXT);
	if(count != 0){
		loot_message(brutus);
	}
	brutus->loot += count;
}

//function to collect coins - made by arnav rajashekara
void collect_coins(void *data){
	struct Sim *world = data;
	iterate(world->mascots, sweep_coins);
}

//function to check if a coin is close enough - made by arnav rajashekara
bool close_enough(void *data, void *helper){
	struct Coin *c = data;
	struct Buckeye *brutus = helper;
	double distance = sqrt((brutus->x_position - c->x_position)*(brutus->x_position - c->x_position) + (brutus->y_position - c->y_position)*(brutus->y_position - c->y_position));
	return distance <= 0.5;
}

//function to check if coin corresponds to brutus - made by arnav rajashekara
bool my_coin(void *data, void *helper){
	struct Coin *c = data;
	struct Buckeye *brutus = helper;
	return ((brutus->color == c->color) && close_enough(c,brutus));
}

//function to clear mascot and coin list - made by arnav rajashekara
void clear_both_lists(void *data){
	struct Sim *world = data;
	if (TEXT){printf("Clearing mascots list...\n");}
	int mascots_deleted = deleteSome(&world->mascots, clear_list, NULL, freeMemory, TEXT);
	if (TEXT){printf("     %d mascots deleted.\n", mascots_deleted);}
	if (TEXT){printf("Clearing coins list...\n");}
	int coins_deleted = deleteSome(&world->coins, clear_list, NULL, freeMemory, TEXT);
	if (TEXT){printf("     %d coins deleted.\n", coins_deleted);}
}

//function to run the simulation - made by arnav rajashekara
void sim_loop(struct Sim *world){
	while(game_on(world, NULL)){
		sort(world->mascots, compare_y);
		master_output(world);
		world->elapsed += DELTA_TIME;
		move_everyone(world);
		collect_coins(world);
	}
	sort(world->mascots, compare_score);
	final_output(world);
	clear_both_lists(world);
}
