/* Arnav Rajashekara */

void clear_both_lists(void *data);
bool close_enough(void *data, void *helper);
void collect_coins(void *data);
void move_everyone(void *data);
bool my_coin(void *data, void *helper);
void sim_loop(struct Sim *world);
void sweep_coins(void *data);
