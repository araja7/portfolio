//Arnav Rajashekara
#include <stdlib.h>
#include <stdio.h>

//struct for the simulation data
struct Sim {
    double elapsed;
    void *mascots;
    void *coins; 
};

//struct for mascot data
struct Buckeye {
    double x_position;
    double y_position;
    double x_velocity;
    double y_velocity;
    double jump_velocity;
    char color;
    int loot;
    struct Sim *sim_ptr;
};

//struct for coin data
struct Coin {
    char color;
    double x_position;
    double y_position;
};
